package Main;

import java.sql.SQLException;

import DAO.AdminDAO.PackageDao;
import DAO.UserDao.UserDao_;
import DAO.UserDao.UserDao__;

public class test02 {
	public static void main(String[] args) throws SQLException {
		UserDao_ use = new UserDao_();
		PackageDao dao = new PackageDao();
		UserDao__ user = new UserDao__();
		/* dao.Insert(); */
		
		/* user.DeletePack(); */
		
		use.searchPWD();
	}
}
